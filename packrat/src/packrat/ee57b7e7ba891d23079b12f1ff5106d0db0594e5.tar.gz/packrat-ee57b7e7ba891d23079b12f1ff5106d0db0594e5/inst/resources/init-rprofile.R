#### -- Packrat Autoloader (version 0.4.1.8) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
